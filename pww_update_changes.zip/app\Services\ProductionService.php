<?php

namespace App\Services;

use App\Exceptions\InsufficientStockException;
use App\Models\LaborLog;
use App\Models\Product;
use App\Models\ProductionLog;
use App\Models\SalesOrder;
use App\Models\Setting;
use App\Models\StaffProfile;
use Illuminate\Support\Facades\DB;

class ProductionService
{
    /**
     * Record a production batch and auto-deduct raw material inventory.
     *
     * @param int $productId
     * @param int $quantityManufactured
     * @param int $quantityRejected
     * @param int $recordedByUserId
     * @param string $productionDate
     * @param array $laborData array of ['staff_profile_id' => x, 'units_completed' => y]
     * @return \App\Models\ProductionLog
     *
     * @throws \App\Exceptions\InsufficientStockException
     */
    public function logProduction(
        int $productId,
        int $quantityManufactured,
        int $quantityRejected,
        int $recordedByUserId,
        string $productionDate,
        array $laborData = []
    ): ProductionLog {
        return DB::transaction(function () use ($productId, $quantityManufactured, $quantityRejected, $recordedByUserId, $productionDate, $laborData) {
            $product = Product::findOrFail($productId);

            $trackStock = Setting::isStockEnabled();

            if ($trackStock) {
                // Fetch BOM items
                $bomItems = $product->billOfMaterials()->with('rawMaterial')->get();

                // Check and deduct raw materials
                foreach ($bomItems as $bom) {
                    $rawMaterial = $bom->rawMaterial;

                    // Total Consumed = quantity_manufactured * required_quantity * (1 + (waste_percentage / 100))
                    $wasteMultiplier = 1 + ($bom->waste_percentage / 100);
                    $totalConsumed = $quantityManufactured * $bom->required_quantity * $wasteMultiplier;

                    if ($rawMaterial->current_stock < $totalConsumed) {
                        throw new InsufficientStockException(
                            $rawMaterial->material_name,
                            $totalConsumed,
                            $rawMaterial->current_stock
                        );
                    }

                    // Deduct stock
                    $rawMaterial->decrement('current_stock', $totalConsumed);
                }

                // Increment product stock
                $product->increment('current_stock', $quantityManufactured);

                // Auto-check and promote in_production Sales Orders if stock is now sufficient
                $inProductionOrders = SalesOrder::where('status', 'in_production')
                    ->with('items.product')
                    ->get();
                foreach ($inProductionOrders as $ord) {
                    $ord->autoPromoteIfStockAvailable();
                }
            }

            // Create production log
            $productionLog = ProductionLog::create([
                'product_id' => $productId,
                'quantity_manufactured' => $quantityManufactured,
                'quantity_rejected' => $quantityRejected,
                'recorded_by' => $recordedByUserId,
                'production_date' => $productionDate,
            ]);

            // Create labor logs if provided
            foreach ($laborData as $labor) {
                if (empty($labor['staff_profile_id']) || ! isset($labor['units_completed'])) {
                    continue;
                }

                $staffProfile = StaffProfile::findOrFail($labor['staff_profile_id']);

                // Calculate payout if wage_type is piece-rate
                $payout = 0.00;
                if ($staffProfile->wage_type === 'per-day') {
                    $payout = $labor['units_completed'] * ($staffProfile->piece_rate_per_unit ?? 0.00);
                }

                LaborLog::create([
                    'staff_profile_id' => $staffProfile->id,
                    'production_log_id' => $productionLog->id,
                    'units_completed' => $labor['units_completed'],
                    'calculated_payout' => $payout,
                    'status' => 'pending',
                ]);
            }

            return $productionLog;
        });
    }
}
