<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffProfile extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'full_name',
        'wage_type',
        'monthly_salary',
        'piece_rate_per_unit',
    ];

    protected $casts = [
        'monthly_salary' => 'decimal:2',
        'piece_rate_per_unit' => 'decimal:2',
    ];

    /**
     * Get the user account associated with the staff member.
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Get the labor logs for the staff member.
     */
    public function laborLogs()
    {
        return $this->hasMany(LaborLog::class, 'staff_profile_id');
    }

    /**
     * Get the daily attendance records for the staff member.
     */
    public function attendanceRecords()
    {
        return $this->hasMany(AttendanceRecord::class, 'staff_profile_id');
    }

    /**
     * Get the monthly salary disbursals for the staff member.
     */
    public function salaryDisbursals()
    {
        return $this->hasMany(SalaryDisbursal::class, 'staff_profile_id');
    }

    /**
     * Get salary advances given to the staff member.
     */
    public function advances()
    {
        return $this->hasMany(SalaryAdvance::class, 'staff_profile_id');
    }

    /**
     * Total pending advance amount for the staff member.
     */
    public function pendingAdvanceTotal(): float
    {
        return (float) $this->advances()->where('status', 'pending')->sum('amount');
    }
}
